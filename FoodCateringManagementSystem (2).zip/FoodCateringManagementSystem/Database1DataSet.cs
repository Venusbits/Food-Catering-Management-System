﻿namespace FoodCateringManagementSystem {
    
    
    public partial class Database1DataSet {
    }
}
